%!PS
%%BoundingBox: 0 -46 74 46 
%%HiResBoundingBox: 0 -45.41519 73.41711 45.41519 
%%Creator: MetaPost 2.01
%%CreationDate: 2023.10.12:1326
%%Pages: 1
%%BeginProlog
%%EndProlog
%%Page: 1 1
gsave newpath 0 45.41519 moveto
73.41711 45.41519 lineto
73.41711 -45.41519 lineto
0 -45.41519 lineto
0 -45.4078 0 45.4078 0 45.41519 curveto closepath clip
 0.8 setgray
newpath 5.24408 45.41519 moveto
15.73224 45.41519 lineto
68.17303 -45.41519 lineto
57.68488 -45.41519 lineto
57.6806 -45.4078 5.24835 45.4078 5.24408 45.41519 curveto closepath fill
 0 setgray 0 0.5 dtransform truncate idtransform setlinewidth pop [] 0 setdash 1 setlinecap
 1 setlinejoin 10 setmiterlimit
newpath 0 0 moveto
209.76318 0 lineto stroke
newpath 0 0 moveto
209.76318 0 lineto stroke
newpath -5.24408 9.08304 moveto
204.5191 9.08304 lineto stroke
newpath -5.24408 -9.08304 moveto
204.5191 -9.08304 lineto stroke
newpath -10.48816 18.16608 moveto
199.27502 18.16608 lineto stroke
newpath -10.48816 -18.16608 moveto
199.27502 -18.16608 lineto stroke
newpath -15.73224 27.24911 moveto
194.03094 27.24911 lineto stroke
newpath -15.73224 -27.24911 moveto
194.03094 -27.24911 lineto stroke
newpath -20.97632 36.33215 moveto
188.78687 36.33215 lineto stroke
newpath -20.97632 -36.33215 moveto
188.78687 -36.33215 lineto stroke
newpath -26.2204 45.41519 moveto
183.54279 45.41519 lineto stroke
newpath -26.2204 -45.41519 moveto
183.54279 -45.41519 lineto stroke
newpath -31.46448 54.49823 moveto
178.2987 54.49823 lineto stroke
newpath -31.46448 -54.49823 moveto
178.2987 -54.49823 lineto stroke
newpath -36.70856 63.58127 moveto
173.05463 63.58127 lineto stroke
newpath -36.70856 -63.58127 moveto
173.05463 -63.58127 lineto stroke
newpath -41.95264 72.6643 moveto
167.81055 72.6643 lineto stroke
newpath -41.95264 -72.6643 moveto
167.81055 -72.6643 lineto stroke
newpath -47.19672 81.74734 moveto
162.56647 81.74734 lineto stroke
newpath -47.19672 -81.74734 moveto
162.56647 -81.74734 lineto stroke
newpath -52.4408 90.83038 moveto
157.32239 90.83038 lineto stroke
newpath -52.4408 -90.83038 moveto
157.32239 -90.83038 lineto stroke
newpath -104.88159 -90.83038 moveto
0 90.83038 lineto stroke
newpath -104.88159 90.83038 moveto
0 -90.83038 lineto stroke
newpath -94.39343 -90.83038 moveto
10.48816 90.83038 lineto stroke
newpath -94.39343 90.83038 moveto
10.48816 -90.83038 lineto stroke
newpath -83.90527 -90.83038 moveto
20.97632 90.83038 lineto stroke
newpath -83.90527 90.83038 moveto
20.97632 -90.83038 lineto stroke
newpath -73.41711 -90.83038 moveto
31.46448 90.83038 lineto stroke
newpath -73.41711 90.83038 moveto
31.46448 -90.83038 lineto stroke
newpath -62.92896 -90.83038 moveto
41.95264 90.83038 lineto stroke
newpath -62.92896 90.83038 moveto
41.95264 -90.83038 lineto stroke
newpath -52.4408 -90.83038 moveto
52.4408 90.83038 lineto stroke
newpath -52.4408 90.83038 moveto
52.4408 -90.83038 lineto stroke
newpath -41.95264 -90.83038 moveto
62.92896 90.83038 lineto stroke
newpath -41.95264 90.83038 moveto
62.92896 -90.83038 lineto stroke
newpath -31.46448 -90.83038 moveto
73.41711 90.83038 lineto stroke
newpath -31.46448 90.83038 moveto
73.41711 -90.83038 lineto stroke
newpath -20.97632 -90.83038 moveto
83.90527 90.83038 lineto stroke
newpath -20.97632 90.83038 moveto
83.90527 -90.83038 lineto stroke
newpath -10.48816 -90.83038 moveto
94.39343 90.83038 lineto stroke
newpath -10.48816 90.83038 moveto
94.39343 -90.83038 lineto stroke
newpath 0 -90.83038 moveto
104.88159 90.83038 lineto stroke
newpath 0 90.83038 moveto
104.88159 -90.83038 lineto stroke
newpath 10.48816 -90.83038 moveto
115.36975 90.83038 lineto stroke
newpath 10.48816 90.83038 moveto
115.36975 -90.83038 lineto stroke
newpath 20.97632 -90.83038 moveto
125.85791 90.83038 lineto stroke
newpath 20.97632 90.83038 moveto
125.85791 -90.83038 lineto stroke
newpath 31.46448 -90.83038 moveto
136.34607 90.83038 lineto stroke
newpath 31.46448 90.83038 moveto
136.34607 -90.83038 lineto stroke
newpath 41.95264 -90.83038 moveto
146.83423 90.83038 lineto stroke
newpath 41.95264 90.83038 moveto
146.83423 -90.83038 lineto stroke
newpath 52.4408 -90.83038 moveto
157.32239 90.83038 lineto stroke
newpath 52.4408 90.83038 moveto
157.32239 -90.83038 lineto stroke
grestore
showpage
%%EOF
